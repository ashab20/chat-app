/*
*Title: Server main page
*Description: connect into the server and socket.io
*Author: Ashab Uddin
*Date: 14/02/2022
*/


// Dependencies
const express = require('express');
const http = require('http')
const socketIo = require('socket.io')
const cors = require('cors');
const dotenv = require('dotenv');
// Module Scafholding
const app = express();
const server = http.createServer(app);
const Io = socketIo(server);
dotenv.config();
const PORT = process.env.PORT;

app.use(cors());

// Routes
app.use('/',(req,res) => {
    res.send('Server connected successfully');
})
    const users = [{}];

// socket ceonnect
Io.on('connection',(socket) => {
    console.log(`New Connection`);

    socket.on('joined',({user}) => {
        users[socket.id] = user;
        console.log(`${user} has Joined`);
        socket.broadcast.emit('userjoined', {user:'Admin',message:`${users[socket.id]} has joined`});
        socket.emit('welcome',{user:'Admin',message:`Welcome to the chat, ${ users[socket.id] ? users[socket.id] : 'Geust'}`});
    });

    socket.on('message', ({id,message}) => {
        Io.emit('sendMessage',{user:users[id],message,id});
    })
    socket.on('disconnect', () => {
        socket.broadcast.emit('leave',{user:'Admin', message:`${users[socket.id]} has leave`});
        console.log(`User left`);
    });

})

// Server Connection
server.listen(PORT, () => {
    console.log(`Server connected into the http://localhost:${PORT}`);
});
