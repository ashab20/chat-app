import React from 'react';
import '../Chat/chat.css';

const Message = ({user,message,classs}) => {
    return (
        <div className={classs}>
            <p className="user">{user} </p> 
            <div>{message}</div>
        </div>
    )
}

export default Message;