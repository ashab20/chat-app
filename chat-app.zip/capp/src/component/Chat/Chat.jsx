/*
? Title: '' 
* Description: ''
! Author: 'Ashab Uddin'
* contact: 'ashabuddin34@gmail.com'
* Date: '00/00/2022'
*/

import { useEffect, useState } from "react";
import ReactScrollToBottom from 'react-scroll-to-bottom';
import socketIO from 'socket.io-client';
import Message from "../Message/Message";
import { user } from "../Signup/Signup";
import './chat.css';

const ENDPOIT = 'https://chatrightnow.herokuapp.com/';
let socket;

const Chat = () => {
    const [id, setId] = useState('');
    const [message, setMessage] =useState([]);

    const send = () => {
        const message = document.getElementById("chatInput").value;
        if(message){ 
            socket.emit('message',{message,id});
            document.getElementById('chatInput').value= '';
        }
    }

    useEffect(() => {
    socket = socketIO(ENDPOIT,{transports: ['websocket']});

    socket.on('connect',() =>{
        setId(socket.id);
    })

    socket.emit('joined',{user}); 
    socket.on('welcome', (data) => {
        setMessage([...message,data]);
    })
    socket.on('userjoined', (data) => {
        setMessage([...message,data]);
        
    })
    socket.on('leave',(data) => {
        setMessage([...message,data]);
    });

    return () => {
        socket.emit('disconnect');
        socket.off();
    }
    
}, []);

useEffect(() => {
    socket.on('sendMessage', (data) => {
        setMessage([...message,data]);
    });

    return () => {
        socket.off();
    }
},[message])


return(        
        <div className="chat">                
            <div className="main">
                <div className="header">
                <div className="titleBar">{user}</div>
                <div className="close">
                    <a title='back' href="javascript:window.history.back()">x</a></div>
                </div>
                <ReactScrollToBottom className="message">
                        {message.map((items,i) =>
                            <Message key={i} 
                            classs={items.id === id ? `sender` : `reciver`} 
                            user={items.id === id ? 'You' : items.user || 'Geust'} message={items.message} />                    
                        
                        )}                    
                </ReactScrollToBottom>
                <div className="chatBox">
                    <input onKeyPress={(e)=>e.key === 'Enter' ? send(): null} type="text" id="chatInput"/>
                    <input onClick={send} type='submit' value='send'/>
                </div>
                </div>
            </div>        
    );
}


export default Chat;