import { useState } from 'react';
import { Link } from 'react-router-dom';
import './signup.css';


let user;


const Signup = () => {
  const [name, setName] = useState('');

  const sendUser = () => {
    user = document.getElementById('joinInput').value;
    document.getElementById('joinInput').value ='';
  }

  return (
    <section className='container'>
        <div className='title'>
          <h1>Your Name</h1>
        </div>
        <div className="form-controll">
          <input type="text" id='joinInput' placeholder='Enter a name' 
          onChange={(e) => setName(e.target.value)}/>
          <Link to='/chat' 
          onClick={(e) => !name? e.preventDefault() : null} >
          <button className='btn' id='joinbtn' onClick={sendUser} type='submit'>Start Chat</button>
          </Link>
        </div>
    </section>

  )
}

export default Signup;
export {user};